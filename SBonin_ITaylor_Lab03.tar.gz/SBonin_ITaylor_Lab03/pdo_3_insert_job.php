<?php

$sql = 'INSERT INTO jobs (job_desc, min_lvl, max_lvl) ' . 
       'VALUES(:desc, :mnl, :mxl)'; 

$user = 'student';
$password = 'nhti'; 
$target = 'mysql:host=localhost;port=3306;dbname=pubs'; 

$jobDescr = 'Copy Editor'; 
$minLvl = 10;
$maxLvl = 20; 

// open database connection
$handle = new PDO($target, $user, $password); 

$stmt = $handle->prepare($sql); 

//$stmt->bindParam(':auid', $authorID, PDO::PARAM_STR); 

$stmt->execute(

    [
    ':desc' => $jobDescr,
    ':mnl'  => $minLvl,
    ':mxl'  => $maxLvl
    ]

); 

$jobId = $handle->lastInsertId();

$handle = null; // close handle 

echo $jobId; 

?> 